#include "libm.h"

double (cimag)(double complex z)
{
	return cimag(z);
}
