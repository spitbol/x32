#include "libm.h"

//FIXME
long double complex ccoshl(long double complex z)
{
	return ccosh(z);
}
