#include "libm.h"

//FIXME
long double complex cexpl(long double complex z)
{
	return cexp(z);
}
