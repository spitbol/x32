#undef __WORDSIZE
#define __WORDSIZE 32
/* FIXME */
